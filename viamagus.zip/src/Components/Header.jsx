export default function Header() {
  return (
    <div className="GameHeader">
      <h3>Today's Games</h3>
    </div>
  );
}
